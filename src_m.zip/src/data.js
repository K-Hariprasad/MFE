export const moviesData = [
  {
    poster_path: "/aciP8Km0waTLXEYf5ybFK5CSUxl.jpg",
    id: 889737,
    title: "Joker: Folie à Deux",
    overview:
      "While struggling with his dual identity, Arthur Fleck not only stumbles upon true love, but also finds the music that's always been inside him.",
    release_date: "2024-10-01",
  },
  {
    poster_path: "/k42Owka8v91trK1qMYwCQCNwJKr.jpg",
    id: 912649,
    title: "Venom: The Last Dance",
    overview:
      "Eddie and Venom are on the run. Hunted by both of their worlds and with the net closing in, the duo are forced into a devastating decision that will bring the curtains down on Venom and Eddie's last dance.",
    release_date: "2024-10-22",
  },
  {
    poster_path: "/cRDJxdnRb7ikKd6fVJTrGeaL34v.jpg",
    id: 1063877,
    title: "Don't Move",
    overview:
      "A grieving woman in a secluded forest encounters a killer who injects her with a paralytic drug. As her body shuts down, her fight for survival begins.",
    release_date: "2024-10-24",
  },
  {
    poster_path: "/hhiR6uUbTYYvKoACkdAIQPS5c6f.jpg",
    id: 976734,
    title: "Canary Black",
    overview:
      "Top level CIA agent Avery Graves is blackmailed by terrorists into betraying her own country to save her kidnapped husband. Cut off from her team, she turns to her underworld contacts to survive and help locate the coveted intelligence that the kidnappers want.",
    release_date: "2024-10-10",
  },
  {
    poster_path: "/bZubW4eLAk2zqk44fSWRDTFfcba.jpg",
    id: 107113,
    title: "Only Murders in the Building",
    overview:
      "Three strangers share an obsession with true crime and suddenly find themselves wrapped up in one.",
    release_date: "2021-08-31",
  },
];
