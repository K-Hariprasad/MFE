import React from "react";
import "./styles.css";

function Header() {
  return (
    <header className="header">
      <div className="logo">
        <h1>MoviesApp</h1>
      </div>
    </header>
  );
}

export default Header;
