import React from 'react'
import Header from './components/header'

function App() {
  return (
    <>
      <Header/>
    </>
  )
}

export default App